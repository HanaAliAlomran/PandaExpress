


import java.util.Scanner;

public class PandaExpress {

    static String c;

    public static void write_comment() {

        System.out.println("Dear student if you have any comment please write it here (:");
        Scanner scan = new Scanner(System.in);
        String[] C = new String[1];
        String stud_coment = scan.next();
        C[0] = stud_coment;
        System.out.println("Thank you for your time:) ");
        c = C[0];
    }
    public static String get_comment(){
        return c;
    }
}