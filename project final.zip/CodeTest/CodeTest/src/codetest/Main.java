 package codetest;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner input= new Scanner(System.in);
        Student obj1 = new Student();
        Orders Info = new Orders();
        ArrayList<Integer> Take_Order = new ArrayList<>();
       
        String abc ;
        String id ;
        String name="";
         Bill billing = new Bill();
        Menu object1 = new Menu();
        Cooks cooo = new Cooks();
        Cooks cook = new Cooks(name);
        Scanner scan2 = new Scanner(System.in);
        Scanner scan= new Scanner(System.in);
        OUTER: do {

            System.out.println("Welcome to Panda Express! >> Student type (1)... Employee type (2) ");


            int S = scan2.nextInt();
            if (S == 1) {
                System.out.println("Enter your name:");
                abc = input.nextLine();
                obj1.Student_name(abc);

                System.out.println("Enter your ID:");
                id = input.nextLine();
                obj1.Student_ID(id);
                System.out.println("Press: 1. Write comment 2.Order 3.View menu");
                int choose = scan.nextInt();

                switch (choose) {
                    case 1:
                       PandaExpress.write_comment();
                        break;
                    case 2:

                        object1.menu();
                        Take_Order = Info.TakeOrder(obj1);
                        billing.Billing(Info.price);
                        break;
                    case 3:
                        object1.menu();
                        System.out.println("Would you like to order? Enter: 1. Yes 2. No");
                        int choice = scan.nextInt();
                        if (choice == 1) {

                            Take_Order = Info.TakeOrder(obj1);
                            billing.Billing(Info.price);

                        } else {
                            System.out.println("Goodbye (:");
                        }
                        break;

                }

            } else if (S == 2) {



                System.out.println("Enter name: ");
                name = scan.next();

                cook.loginAsCook(name);
                System.out.println(">> Review Comments(Enter 1) View order(Enter 2) ");
                int chose = scan.nextInt();
                switch (chose) {

                 
                    case 1 :
                        cooo.review(PandaExpress.get_comment());
                        break ;
                    case 2 :
                        cooo.view_order(Info,obj1);
                }
            }
            System.out.println("Welcome >> Student type (1)... Employee type (2) ");

        }

        while (scan2.hasNextInt()==true);
    }


    
}

class Student {

    private String student_name;

    public void Student_name(String name) {

        student_name = name;

    }

    public String getStudent_name() {
        return student_name;
    }

    private String student_ID;

    public void Student_ID(String ID) {

        student_ID = ID;

    }

    public String getStudent_ID() {
        return student_ID;
    }
}


class Orders extends Student {
    String name, ID;
    int quantity;
    int Iterate;
    ArrayList<Integer> scan = new ArrayList<>(); 
    ArrayList<Integer> quantArray = new ArrayList<>();
    public void view_orders(Student student){
        System.out.println("Order given by "+student.getStudent_name()+" ID "+student.getStudent_ID()+" Quantity "+ quantity);
    }

    Orders() {
        this.name = super.getStudent_name();
        System.out.println(this.name);
        this.ID = super.getStudent_ID();
        System.out.println(this.ID);
    }

    public ArrayList<Double> price = new ArrayList<>();

    public ArrayList<Integer> TakeOrder(Student student) {

        Scanner scanner = new Scanner(System.in);


        Iterate = 0;
        
        System.out.println("Enter the number of the order:");
        System.out.println("*Note: Enter 4 when Done");
        OUTER: do {


            scan.add(scanner.nextInt());
            if (null == scan.get(Iterate)) {
                System.out.println("Order is not on the Menu, Check and Order again ):");

                break;
            } else {

                switch (scan.get(Iterate)) {
                    case 1:

                        System.out.println("Enter the quntity");
                        quantity = scanner.nextInt();
                        System.out.println("You've Ordered" + " " + quantity + " " + "Burgers!");
                        price.add(10.00 * quantity);
                        
                        quantArray.add(quantity);

                        break;
                    case 2:
                        System.out.println("Enter the quntity");
                        quantity = scanner.nextInt();
                        System.out.println("You've Ordered" + " " + quantity + " " + "Fries!");
                        price.add(5.50 * quantity);
                        
                        quantArray.add(quantity);
                        break;
                    case 3:
                        System.out.println("Enter the quntity");
                        quantity = scanner.nextInt();
                        System.out.println("You've Ordered" + " " + quantity + " " + "Pepsi!");
                        price.add(3.00 * quantity);
                        
                        quantArray.add(quantity);
                        break;
                    case 4:
                        if (scan.isEmpty() == true) {
                            System.err.println("No order is entered!");
                            break OUTER;
                        } else {
                            System.out.println("Your Order is in the making! Wait for the bill (:");
                            Confiramtion(scan, Iterate, quantArray,student);
                        }
                        break OUTER;
                    default:
                        System.out.println("Order is not on the Menu, Check and Order again ):");
                        break;
                }
            }
            Iterate++;

        } while (scanner.hasNextInt() == true);

        return scan;
    }
    
    //time method
    public void PickUp() {

        Scanner scanner = new Scanner(System.in);
        int time = scanner.nextInt();
        String range = scanner.nextLine().toUpperCase();

        if (time<7&&range=="AM"){
            System.err.println("We're Closed by this time");
        }
         if(time>3&&range=="PM"||time>3&&range=="AM"){
            System.err.println("We're Closed by this time");

        }
        else {
            System.out.println("You're all set!");
        }

    }

    public void Confiramtion(ArrayList<Integer> Order, int size, ArrayList<Integer> quantArr, Student student) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Name:" + " " +student.getStudent_name());
        System.out.println("ID:" + " " + student.getStudent_ID());
        System.out.println("Your Order is: " + " ");

        for (int i = 0; i < size; i++) {
            switch (Order.get(i)) {
                case 1:
                    System.out.println(quantArr.get(i) + " " + "Burgers");
                    break;
                case 2:
                    System.out.println(quantArr.get(i) + " " + "Fries");
                    break;
                default:
                    System.out.println(quantArr.get(i) + " " + "Pepsi");
                    break;
            }
        }
        System.out.println("Press 1.Confirm 2.Cancel");
        int choice = scanner.nextInt();
        switch (choice) {
            case 1:
                System.out.println("Your order is confirmed! what hour are you picking it up (please include am/pm):");
                PickUp();

                break;
            case 2:
                Order.clear();
                quantArr.clear();
                price.clear();
                System.out.println("Your order is canceled");
                break;
            default:
                System.err.println("Wrong entry!");

        }
    }
}

class Menu {
    public void menu() {
        System.out.println("********Welcome******** \n1. Burger (10.00 S.R) \n2. Fries (5.50 S.R)\n3. Pepsi (3.00S.R)");
    }
}

class Bill {

    public void Billing(ArrayList<Double> bill) {
        Scanner scan = new Scanner(System.in);

        double bill_total = 0.0;
        for (int i = 0; i < bill.size(); i++) {
            bill_total += bill.get(i);
        }

        System.out.println("Bill: " + " " + bill_total);
if (bill_total!=0.0){
        System.out.println("Do you have any Coupon code: (yes/no)");

        String answer = scan.next();
        String apply = "";
        if (answer.equalsIgnoreCase("yes")) {
            System.out.println("Apply coupon: ");
            apply = scan.next();
        } else {
            System.out.println("No coupon code added!");
        }

        if (apply.isEmpty()) {
            System.out.println("Thank you for ordering!");
        } else {
            System.out.println("Coupon applied successfully!");
            Add_Codes[] getAllCodes = Cooks.getAllCodes();
            bill_total = applyCoupon(bill_total, getAllCodes, apply);
            System.out.println("Bill: " + " " + bill_total);
            System.out.println("Thank you for ordering!");
        }

    }
    }
    public double applyCoupon(double bill_total, Add_Codes[] codes, String apply) {
        for (int i = 0; i < codes.length; i++) {
            if (codes[i].getCode().equals(apply)) {
                double discountAmount = (bill_total * codes[i].getDiscount()) / 100;
                bill_total = bill_total - discountAmount;
                return bill_total;
            }
        }
        return bill_total;
    }

}
class Add_Codes {
    private String code;
    private double discount;

    public Add_Codes(String code, double discount) {
        this.code = code;
        this.discount = discount;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

}

class Cooks {
    private String cookName;
    private String password;

    public void review(String coomment) {
        System.out.println(coomment);
    }

    public Cooks() {

    }
    public void view_order(Orders orders, Student student){
        orders.view_orders(student);
    }

    public Cooks(String name) {
        this.cookName = name;
        this.password = "123";
    }

    public String getCookName() {
        return cookName;
    }

    public void setCookName(String cookName) {
        this.cookName = cookName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

/// if cook enters use login method

    public void loginAsCook(String name) {
        this.cookName = name;
        System.out.println("Enter your password:");
        Scanner scanner = new Scanner(System.in);
        int pass;

        while (true) {
            pass = scanner.nextInt();
            if (pass==123) {
                System.out.println("Login successfull!");
                break;
            } else {
                System.out.println("please enter password again");
            }
        }
    }

    public static Add_Codes[] getAllCodes() {
        Add_Codes code1 = new Add_Codes("AN532", 10);
        Add_Codes code2 = new Add_Codes("AB098", 15);
        Add_Codes code4 = new Add_Codes("ASD234", 20);
        Add_Codes code5 = new Add_Codes("JU000", 25);

        Add_Codes[] codes = { code1, code2, code4, code5 };
        return codes;
    }

}

